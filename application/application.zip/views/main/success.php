<div id="contact-page" class="container">
    <div class="bg">
        <!--
        <div class="row">
            <div class="col-sm-12">
                <h2 class="title text-center">Contact <strong>Us</strong></h2>
                <div id="gmap" class="contact-map">
                </div>
            </div>
        </div>
        -->
        <?
            $phone = 'info@kroykorun.com';
        ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="contact-form">
                    <h2 class="title text-center">Order successfully taken, Please save the cash receipt for your own safety, for further information >mail : "<? echo $phone; ?>".<br>click the link :<a target="_blank" href="<? echo base_url().'orders/'.$filename ?>"> Cash Receipt</a></h2>
                </div>
            </div>
        </div>
    </div>
</div><!--/#contact-page-->