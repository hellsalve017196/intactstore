

<script src="<? echo base_url()."res/static/js/jquery.js" ?>"></script>
<script src="<? echo base_url()."res/static/js/bootstrap.min.js" ?>"></script>
<script src="<? echo base_url()."res/static/js/jquery.scrollUp.min.js" ?>"></script>
<script src="<? echo base_url()."res/static/js/price-range.js" ?>"></script>
<script src="<? echo base_url()."res/static/js/jquery.prettyPhoto.js" ?>"></script>
<script src="<? echo base_url()."res/static/js/main.js" ?>"></script>



<a id="scrollUp" href="file:///home/zn/Desktop/Eshopper/index.html#top" style="display: none; position: fixed; z-index: 2147483647;"><i class="fa fa-angle-up"></i></a>


</body>
</html>